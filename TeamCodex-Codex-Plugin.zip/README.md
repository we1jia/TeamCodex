# TeamCodex

面向 Codex 与 ChatGPT 桌面端的轻量级无侵入实时协同工作区与上下文接力同步中枢。  
告别“同事互相甩二手 AI 文档产生误差”，实现研发团队对话上下文与思维链的毫秒级无损对齐。

Seamless Real-time Collaboration Workspace & Context Hub for Codex & ChatGPT Desktop.  
Stop cascading errors from tossing static AI docs. Align reasoning chains and context instantly across engineering teams.

[![Release](https://img.shields.io/github/v/release/we1jia/TeamCodex?color=ea580c&style=flat-square)](https://github.com/we1jia/TeamCodex/releases)
[![Build](https://img.shields.io/badge/build-passing-16a34a?style=flat-square)](https://github.com/we1jia/TeamCodex/actions)
[![Tests](https://img.shields.io/badge/tests-59%2F59%20passed-16a34a?style=flat-square)](tests/)
[![Platform](https://img.shields.io/badge/platform-macOS%20%7C%20Windows-52525b?style=flat-square)](https://github.com/we1jia/TeamCodex/releases)
[![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-f97316?style=flat-square)](server/dev_host.mjs)
[![License](https://img.shields.io/badge/license-MIT-52525b?style=flat-square)](LICENSE)

[English](#english) | [中文](#中文)

---

<a id="中文"></a>

## 中文

### 1. 立项初衷：为什么做这款工具？

在研发团队全员使用 Codex / ChatGPT 进行编码与架构攻坚时，个人单兵作战效率显著提升，但**团队协作却滑入了新的泥潭**：

- **痛点一：同事互相“甩二手 AI 文档”，导致误差与幻觉层层放大**  
  最典型的翻车现场：同事 A 问完 AI，直接把 AI 吐出的一大篇未经实测验证的 Markdown/Word 方案或接口草案打包“甩”给同事 B。同事 B 拿到这份二手文档再去喂给自己的本地 AI，导致两台机器在充满假定条件和虚假代码的前提下二次演绎，幻觉与误差被指数级放大，联调上线时频频踩坑互相扯皮。
- **痛点二：丢失前因后果与决策链路（The Missing "Why"）**  
  静态文档只呈现了 AI 最终吐出的一份“看似工整”的结果，却抹平了极其关键的技术推导背景——“排除了哪些踩坑方案？底层选型的边界依赖是什么？Prompt 经历过哪些纠偏？”接手的同事面对冰冷静态文本，根本无法理解前置设计意图。
- **痛点三：Prompt 孤岛与重复试错**  
  同事 A 花费半天向 AI 灌输了复杂业务规则并调优出排错上下文；同事 B 接手相关模块时其本地 AI 依然处于“失忆”状态，只能重新编写 Prompt 从零踩坑，重复消耗大量 Token 与工时心智。
- **痛点四：聊天工具手工搬运低效且极易泄密**  
  传统的微信/飞书截图或大段文本拷贝，不仅信息衰减严重，而且极易在剪贴板中意外泄露本地工程绝对路径、环境变量甚至 Shell 命令行密码。

**TeamCodex 的核心解法：以“真实动态上下文快照”彻底取代“甩二手静态文档”**：  
TeamCodex 将 **AI 的动态多轮推理链路（Context Chain）** 转化为像 Git Commit 一样可沉淀、可脱敏、可秒级接力的团队级资产。
- **原生内嵌**：通过 CDP 协议无侵入挂载在 Codex / ChatGPT 官方客户端侧栏，不破坏原生使用习惯；
- **一键脱敏快照**：随时将当前会话打包为自动过滤本地私密路径的协作快照；
- **秒级上下文对齐**：协作者在自己电脑上一键点击【导入】，完整的多轮思考过程即刻注入当前活动对话，让全团队的 AI 始终运行在**完全统一的事实基准面（Single Source of Truth）**上，从根源上消灭传话误差。

#### 架构概览：独立会话，共享房间，双向协作

每位成员拥有完全独立的本地 AI 会话边界，在同端通过 CDP 挂载 Team 工作区连接同一个 Hub。成员通过同一个 Hub 交换已分享的会话快照与协作资产；每个人自主决定把哪些内容导入自己的 AI 会话中。

<p align="center">
  <img src="docs/assets/architecture_zh.png" alt="TeamCodex 成员双向协作架构：独立会话、共享房间、HTTP 请求与 SSE 更新、Hub 持久化存储与可选插件入口" width="100%" />
</p>

**按一次协作流转来读图**：成员 A 选择会话并分享 → Hub 保存快照并推送更新给同房间成员 → 成员 B 在 Team 工作区查看 → 成员 B 选择性导入自己的本地 AI 会话。实时推送绝不会自动把所有团队对话无差别强塞进每位成员的私有 AI 会话中。

- **对等双向协作**：每位成员既能分享也能导入，A 与 B 是平等的协作者，不直接合并本地底层私密会话；
- **严格私有边界**：未分享的会话严格保留在本机，绝不因为加入团队房间而产生隐式同步或泄露；
- **协作中枢 Hub**：承载同房间口令与成员权限、消息与快照、在线状态感知，以及任务看板、知识库、素材库和工作日历；
- **持久化与插件入口**：Hub 统一在所在机器持久化存储消息、快照与上传文件；可选的 Codex 插件（Skills / Hook）可按需读取 Hub 摘要注入当前任务；
- **本机伴侣挂载**：伴侣程序与注入器通过 CDP 挂载 Team 工作区；CDP 不是跨机器协作通道，跨机通信统一由轻量级 HTTP API + SSE 协议承载。

[查看矢量原图](docs/assets/architecture_zh.svg) · [部署说明](docs/HUB_DEPLOYMENT.md)

维护图片：运行 `python3 scripts/generate_architecture_members.py`（或 `python3 scripts/generate_architecture_diagram.py`），使用 Chrome / Chromium 自动生成中英文矢量 SVG 和 3200 × 2240 高清 PNG；可通过 `CHROME_BIN` 指定浏览器路径。

---

### 实机演示：全新全景协同实机演示 (Live Demo)

以下为真实环境下 **Mac 宿主机** 与 **Windows 11 协同端** 的全新全景双语实机演示（全长 80 秒，涵盖新版看板/素材库/权限流转及跨端秒级上下文注入，已提速并配有完整双语字幕解说，高清完整视频参见 [docs/assets/teamcodex_demo.mp4](docs/assets/teamcodex_demo.mp4)）：

<p align="center">
  <img src="docs/assets/teamcodex_demo.gif" alt="TeamCodex 跨端实时协同、全景看板、素材流转与上下文一键注入实机演示" width="100%" />
</p>

- 📋 **1. 任务看板与权限流转**：任务卡片多状态（待处理、进行中、已完成）拖拽流转，房间口令与角色权限即时鉴权，全员状态毫秒级实时同步；
- 📁 **2. 素材库与多格式附件导入**：支持代码、文档、图片与文件夹快速拖拽上传与即时分发，构建团队统一研发物料池；
- 🚀 **3. Mac 端一键脱敏分享**：在 Codex 客户端侧边栏点击【分享对话】，选择任意排查或攻坚会话，一键生成脱敏快照并广播；
- ⚡ **4. Windows 端毫秒级感知与无损接力**：虚拟机/远程协同端零延迟自动上屏新卡片，协作者一键【选择对话导入】，选定思维链与上下文瞬时注入新会话，根除二次传话误差与模型幻觉。

---

### 2. 客户端下载与交互体验

前往 **[GitHub Releases 最新发布页](https://github.com/we1jia/TeamCodex/releases)** 下载官方原生安装包：

| 平台 | 安装包 | 交互形态与体验 |
|---|---|---|
| **macOS** | [`TeamCodex-macOS.dmg`](https://github.com/we1jia/TeamCodex/releases/latest) | 拖入 `Applications` 即可。状态栏全面升级为**纯白微矢量双云协同图标（Template Icon）**，带 1.7pt 负空间立体切缝与 `>_` 终端镂空，自适应深浅模式；点击弹出原生磨砂 Mini Dashboard 悬浮卡片 |
| **Windows** | [`TeamCodex-Setup.exe`](https://github.com/we1jia/TeamCodex/releases/latest) | 运行向导自动适配 ARM64/AMD64，常驻系统托盘，静默接管无黑框。**左键点击弹出原生深色悬浮卡片**（失焦/Esc 自动收起）；**右键点击弹出纯净原版上下文菜单**（点击【退出】秒速退出无卡死）；具备全局单实例 Mutex 互斥防双图标 |
| **免安装便携版** | `TeamCodex-macOS.zip` / `TeamCodex-Windows-arm64-amd64.zip` | 解压即用，适合移动介质或严格权限环境，Windows 附带 `退出TeamCodex.cmd` 应急一键清理工具 |
| **Codex 官方插件** | [`TeamCodex-Codex-Plugin.zip`](https://github.com/we1jia/TeamCodex/releases/latest) | 官方标准 Codex 插件包。赋予 AI 主动读写空间能力，集成 `UserPromptSubmit` 自动 Hook 摘要注入与预置指令 |

> **提示**：启动后应用常驻系统托盘/状态栏，点击即可展开 **Mini Dashboard 控制面板**，具备：
> - **状态自检**：实时显示 Codex 挂载状态（🟢 已挂载 / 🟡 等待挂载 / 🔴 未连接）、中枢地址与在线房间；
> - **一键操作**：支持【启动并挂载 Codex】、【复制 Smart Token】、【切换中枢地址】与【重启注入】；
> - **无感热更与版本检测**：自动拉取最新侧栏注入脚本，检测到底层新版本时支持一键下载；
> - **优雅退出**：右键菜单提供纯净退出选项，系统级强杀彻底消灭后台孤立进程。

---

### 3. 部署方案与网络拓扑

中枢服务（Hub）支持从本地单机到私有云的三种运行模式：

| 模式 | 运行位置 | 客户端接入方式 | 适用场景 |
|---|---|---|---|
| **单机跨端（默认）** | Mac 宿主机后台静默自启 | Windows 虚拟机自动探测宿主机 IP 直连 | Mac + Win 虚拟机本地开发（零配置） |
| **局域网协同** | 办公室内常开 PC / Mac / NAS | 填入该主机局域网 IP 或粘贴 Smart Token | 5 ~ 30 人同内网/同 Wi-Fi 研发小组 |
| **云端公网部署** | Linux 云服务器 (VPS) | 绑定域名并通过 Nginx HTTPS 反代接入 | 跨地域、远程办公的分布式团队 |

---

### 4. 中枢极速部署（局域网 / 云端）

#### 选项 A：一行命令自动化部署（推荐服务器使用）
```bash
curl -fsSL https://raw.githubusercontent.com/we1jia/TeamCodex/main/scripts/deploy-hub.sh | bash
```
脚本智能探测系统环境与权限：优先通过 Docker 容器化启动；无 Docker 权限时自动降级采用原生 Node.js（零 npm 依赖，毫秒级启动），自动注册 Systemd、PM2 或 Crontab 开机自启守护，并执行接口自检。

#### 选项 B：一键发给终端 AI Agent 的部署提示词
使用 Claude Code、Codex、Cursor、OpenClaw 等终端 AI 运维服务器时，直接复制以下提示词发送：

```text
请帮我在当前服务器部署 TeamCodex Hub 中枢服务：
1. 检查服务器环境：需具备 Docker 或 Node.js >= 18（Hub 是纯原生 Node.js 实现，零 npm 依赖）；
2. 准备代码目录：若是 root 用户克隆至 /opt/TeamCodex，若是普通用户克隆至 ~/TeamCodex（若已存在则 git pull）；
3. 启动中枢服务：
   - 若具备 Docker 守护进程权限，执行 docker compose up -d；
   - 若无 Docker 权限，直接运行 node server/dev_host.mjs（可使用 pm2 或 nohup 守护，并配置开机自启）；
4. 网络与端口：服务默认监听 0.0.0.0:18765；若是云服务器直连请确保安全组放行 18765 端口；
5. 验证健康度：执行 curl http://127.0.0.1:18765/api/health 确保返回 {"ok":true}；
6. 若有 Nginx 反代：代理至 http://127.0.0.1:18765，配置中必须包含 proxy_buffering off; 以保证 SSE 流式推送正常；
7. 输出本机的访问地址（内网/Tailscale/公网）与系统默认空间口令（如 Hub: http://<IP>:18765 | Room: Media）。
```

完整参数表、Docker 编排配置与 Nginx SSL 模板参见：**[中枢部署与网络接入全景指南 (docs/HUB_DEPLOYMENT.md)](docs/HUB_DEPLOYMENT.md)**。

---

### 5. 核心特性

- **全功能团队工作区（看板 / 知识库 / 素材库 / 日历）**：原生无缝集成任务四态看板、闭环审核流转、知识库全文检索、SHA-256 内容寻址素材库与工作日历，让 AI 会话与工程研发生命周期紧密闭环。
- **原生内嵌与菜单栏伴侣**：基于 CDP 动态挂载侧栏，配套 macOS 菜单栏 / Windows 托盘极简 Mini Dashboard，不抢占主工作区。
- **免重装双轨热更新**：连集中 Hub 时，侧栏注入脚本启动时自动动态下发并缓存生效，90% 的日常迭代免下载新包；底层外壳直通 Releases 检查。
- **高亮生命周期互斥**：全屏协作与原生会话保持单选高亮，切回历史对话 100% 恢复原生高亮。
- **跨平台多端识别与心跳保活**：自动探测网络与操作系统，智能区分 `Mac` 与 `Win` 设备身份，支持在线同名去重与活跃列表动态广播。
- **脱敏快照与上下文接力**：一键打包会话并剔除本地路径与 Shell 命令，协作者可一键导入当前活动对话。
- **智能协同口令 (Smart Token)**：支持形如 `Hub: <URL> | Room: <Name> | Key: <Password>` 的单行口令秒级加入与面板快捷复制。

---

### 6. Codex 官方原生插件与 AI 协同赋能 (Plugin / Skills / Hooks)

除了供人类开发者交互的左侧栏工作台与系统托盘伴侣外，TeamCodex 深度集成了 **Codex 官方标准插件体系**（包含 `.codex-plugin/plugin.json` 清单、`skills/` 语义技能与 `hooks/` 生命周期拦截器）。

<p align="center">
  <img src="docs/assets/codex_plugin_detail.png" alt="Team Codex 官方插件详情与自然语言交互" width="95%" />
</p>

#### 双核协同分工体系
- **左侧栏 `Team` Tab（人类看板）**：给**工程师**使用。提供沉浸式全屏群聊、在线成员头像、多房间切换、快照时间线浏览与手动一键导入；
- **`Team Codex` 插件（AI 手脚与耳朵）**：给**当前会话中的 AI 助手**使用。赋予 Codex 读写团队空间、提炼讨论摘要、自动同步上下文的 Tool 能力，开发者无需切屏，用自然语言即可指挥 AI 协同。

#### 1) 三大自然语言预置指令 (Preset Prompts)
在 Codex 对话框中直接输入或点击气泡：
- **`打开 Team Codex 团队协作空间。`**  
  👉 调起协同中枢与本地控制台，引导聚焦左侧栏 Team 面板；
- **`读取当前团队空间的讨论摘要。`**  
  👉 自动调用 API 获取团队当前空间的成员共识、架构方案版本与关键意见，无缝注入当前任务；
- **`把当前 Codex 对话分享到团队空间。`**  
  👉 自动打包当前多轮推理链条，剔除本地敏感路径后广播至团队中枢。

#### 2) `UserPromptSubmit` Hook 自动化上下文注入机制
- **提问前静默探测**：在用户每次向 Codex 提交代码问题前，Hook 在 1200ms 内静默请求 `http://127.0.0.1:18765/api/compact.txt`；
- **毫秒级上下文注入**：自动提取团队最新决策与成员变更，作为 `additionalContext` 隐式附带在提示词中，让 AI 的回答始终建立在全团队最新的共识之上；
- **高可用与零阻塞**：若本地或局域网中枢暂时未启动或发生超时，Hook 0 毫秒静默跳过，绝不阻塞开发者的日常编码。

#### 3) 插件安装与启用方式
- **源码安装（推荐开发者）**：在终端执行：
  ```bash
  codex plugin add /path/to/TeamCodex
  ```
- **离线导入**：从 [GitHub Releases](https://github.com/we1jia/TeamCodex/releases/latest) 下载 `TeamCodex-Codex-Plugin.zip` 并在 Codex 插件管理界面点击导入；
- **界面开启**：在 Codex 客户端左侧导航进入【插件】-> 找到【Team Codex】-> 开启右上角紫色 Toggle 开关即可。

---

### 7. 团队全功能工作区：看板、知识库、素材库与工作日历 (Workspace)

TeamCodex 不仅实现了会话上下文的实时接力，更在客户端内原生打造了**围绕 AI 研发全生命周期的轻量级团队工作区**，告别碎片化的聊天记录，让每一次技术决策、资料沉淀与任务交付都有据可查。

<p align="center">
  <img src="docs/assets/team-workspace-board-dark.png" alt="TeamCodex 任务看板（深色模式）" width="49%" />
  <img src="docs/assets/team-workspace-calendar-light.png" alt="TeamCodex 工作日历（浅色模式）" width="49%" />
</p>
<p align="center">
  <img src="docs/assets/team-workspace-native-light.png" alt="TeamCodex 原生客户端侧栏集成（Windows 浅色）" width="80%" />
</p>

#### 1) 敏捷任务看板与闭环审核流 (Kanban & Review Flow)
- **四态看板流转**：清晰划分为【待开始】、【进行中】、【等待审核】与【已完成】四大流转阶段；
- **全维度任务元数据**：支持指派主要负责人、协作者（支持跨端多选，如同时指派 `weijia(Mac)` 与 `weijia(Win)`）、专属审核人；精确记录起止日期、审核日期、优先级、阻塞原因、验收要求与交付说明；
- **严谨闭环审核机制**：提交审核必须指定审核人并填写交付产物说明；仅指定审核人具备【通过】或【退回】权限，退回必须注明具体原因，审核中状态锁定以防篡改。

#### 2) 统一知识库与素材库 (Knowledge Base & Asset Library)
- **多格式资料纳管**：支持 Markdown 文档编写、代码片段及各类附件上传（单文件上限 10MB，正文全文索引达 20 万字符），支持全文快速检索与分类/标签过滤；
- **细粒度权限控制**：资料支持【仅我可见】（私人资料）与【当前项目共享】一键切换；私人资料受严格鉴权保护，绝不进入公开广播与旧聊天快照；
- **SHA-256 内容寻址复用**：素材库与知识库共用资料底座，相同内容文件按 SHA-256 摘要秒级去重复用，提供安全的图片就地预览与原文件下载。

#### 3) 多成员工作日历 (Work Calendar)
- **日程全景看板**：根据成员独立配置的时区、工作日与不可用日期自动呈现执行与审核安排；
- **排期智能预警**：清晰标识非工作日提醒、逾期任务告警以及待排期任务清单，避免工期延误。

#### 4) 对话上下文精准引用 (Context Citation)
- **安全结构化引用**：在 Team 对话中可一键选择任务或已共享资料，生成包含来源 ID、版本与快照读取时间的结构化上下文；
- **人类最终把关**：确认后仅填入输入框供审查修改，**绝不自动盲发或越权执行指令**，确保安全可控。

---

### 8. 仓库结构

推送 `main` 后会自动测试、递增版本、打包并发布 GitHub Release；普通分支和 PR 只运行检查。详见[自动发布流程](docs/AUTO_RELEASE.md)。

```text
TeamCodex/
├── .codex-plugin/              # 官方 Codex 插件清单与元数据 (plugin.json)
├── hooks/                      # 提问前自动上下文注入钩子 (UserPromptSubmit)
├── skills/                     # 语义化技能指令定义 (skills/team-codex/SKILL.md)
├── assets/                     # 插件与客户端图标、Logo 及界面插图
├── inject/                     # CDP 客户端侧注入层、Web Component 与全屏协作 UI
│   ├── sidebar_fullscreen.js   # 侧栏嵌入、快照脱敏与协同状态机
│   ├── workspace.js            # 工作区（看板/知识库/素材库/日历）前端组件与状态管理
│   ├── workspace.css           # 原生主题自适应样式与紧凑响应式布局
│   └── attach_codex.mjs        # 动态拉取中枢最新脚本、CDP 挂载与心跳同步
├── server/                     # 零依赖原生 Node.js 协作服务
│   ├── dev_host.mjs            # SSE 实时协同中枢 (18765端口，在线人数/多房间/鉴权)
│   ├── workspace_store.mjs     # 工作区原子写入与 JSON 持久化存储
│   ├── workspace_routes.mjs    # 工作区 RESTful API 路由与权限校验
│   ├── workspace_validation.mjs # 任务/资料字段合法性与安全过滤校验
│   └── launcher_host.mjs       # 本地托盘控制面服务 (18767端口，自检/更新/口令)
├── ui/                         # 前端 UI 资源
│   ├── index.html              # 独立全屏协作网页端
│   ├── workspace.html          # 工作区独立入口页面
│   └── panel.html              # 菜单栏/托盘 Mini Dashboard 悬浮控制卡片
├── macos/                      # macOS 菜单栏客户端与打包套件
│   ├── TeamCodex.swift         # 原生 Swift 状态栏应用源码 (Cocoa + WebKit)
│   ├── TeamCodex-Status.png    # 纯白微矢量双云协同图标 (Template Icon, 自适应深浅主题)
│   ├── launch.sh               # 运行时自检与守护脚本
│   └── build_dmg.py            # 自包含 DMG 构建器 (集成 swiftc 自动编译)
├── windows/                    # Windows 托盘套件与 NSIS 安装包工程
│   ├── tray-teamcodex.ps1      # 原生系统托盘控制台 (左键原生弹窗 + 右键原版菜单)
│   ├── run-teamcodex.ps1       # 启动守护与单实例 Mutex 互斥接管
│   ├── 退出TeamCodex.cmd       # [应急工具] 一键强杀所有后台进程并清理托盘
│   └── installer.nsi           # NSIS 安装向导配置
├── scripts/                    # 运维与自动化部署脚本 (deploy-hub.sh)
├── docs/                       # 架构设计、工作区规范与网络接入全景指南
│   ├── WORKSPACE.md            # 工作区数据模型、权限控制与 API 规范指南
│   ├── HUB_DEPLOYMENT.md       # 中枢部署与网络接入全景指南
│   └── assets/                 # 架构图、实机演示与工作区截图
├── tests/                      # 全自动化测试套件 (工作区/权限/状态机/打包)
├── version.json                # 客户端版本定义（自动发布时同步更新）
├── Dockerfile                  # 极简 Alpine Node 生产镜像定义
├── docker-compose.yml          # 一键容器化服务编排
└── README.md
```

---

### 9. 自动化测试

```bash
node --test tests/test_boost_fixes.mjs
node --test tests/test_rooms_and_auth.mjs
node --test tests/test_workspace.mjs tests/test_workspace_bridge.mjs tests/test_workspace_http.mjs
# 验证：全覆盖测试均顺利通过（涵盖插件状态机、房间鉴权、工作区权限与原子持久化）
```

---

### 10. 常见问题 (FAQ)

- **Q: 以后功能更新需要全员重新下载安装包吗？**  
  **日常更新完全不需要**。TeamCodex 采用双轨更新机制：侧栏协作界面与注入逻辑会在连接团队集中中枢时自动热加载最新脚本；仅在涉及操作系统底层驱动或托盘框架升级时，控制面板才会提示下载新版安装包。
- **Q: 个人在本地单机使用，需要额外搭建服务器吗？**  
  **不需要**。macOS 启动时会自动常驻轻量中枢，Windows 虚拟机客户端通过虚拟网络自动发现并连入，完全免配置。
- **Q: 数据安全与隐私边界如何保证？**  
  **纯局域网与私有部署**。数据存储于自建环境的 `data/messages.json`，无任何外部云端遥测。
- **Q: 通过 Nginx 反代后消息无法实时推送？**  
  SSE 依赖流式长连接，Nginx 对应 `location` 必须配置 `proxy_buffering off;`。

---

<a id="english"></a>

## English

### 1. Motivation: Why We Built TeamCodex?

While individual engineers code faster with Codex and ChatGPT, **team engineering is sliding into a costly collaboration bottleneck**:

- **The "Document Tossing" Fallacy & Cascading Hallucinations**  
  A developer prompts the AI, exports a lengthy, unverified markdown document or draft spec, and casually tosses it to a colleague. The recipient feeds this second-hand AI output into their own AI. Unchecked assumptions and fake methods in the original doc get compounded, resulting in severe hallucinations, broken contracts, and endless debugging friction.
- **Erasing Decision Rationale (The Missing "Why")**  
  Static documents show only the final AI code snippet, completely erasing the vital problem-solving trajectory: "Which alternative architectures were ruled out? What boundary constraints were established? How was the prompt refined?" The next engineer inherits cold text without context, forced to guess the design intent.
- **Prompt Silos & Redundant Trial-and-Error**  
  Engineer A spends hours steering the model through nuanced domain rules and subtle edge cases. When Engineer B picks up the next task, their local AI starts with zero memory, forcing them to reinvent prompts and repeat costly mistakes.
- **Manual Copy-Paste is Lossy and Leaky**  
  Sharing screenshots or chat dumps over Slack/Discord flattens rich multi-turn reasoning chains while risking accidental exposure of local absolute filepaths, private tokens, and shell command histories.

**The Solution: Live Context Snapshots over Second-Hand Static Docs**:  
TeamCodex turns **AI conversation state into a first-class collaborative asset**—just like Git commits for source code.
- **Native Embedding**: Injected into official Codex / ChatGPT desktop sidebars via CDP without modifying native executables;
- **One-Click Sanitized Snapshots**: Instantly package active conversation threads with automatic scrubbing of local private paths;
- **Sub-Second Context Relay**: Peers click to import the full reasoning trajectory into their own active sessions, ensuring the entire team operates on a **single, verified source of truth**.

#### Architecture: Separate Sessions, Shared Room, Two-Way Collaboration

Each member maintains a strictly isolated local AI session boundary while mounting the Team workspace via CDP on the same device to connect to the common Hub. Members exchange explicitly shared snapshots and collaborative assets through the Hub; each person decides what to import into their own AI session.

<p align="center">
  <img src="docs/assets/architecture_en.png" alt="TeamCodex Architecture: Separate Sessions, Shared Room, Two-Way Collaboration, Hub Persistence, and Optional Plugin Entry" width="100%" />
</p>

**Follow one collaboration flow**: Member A selects a chat and shares → Hub stores the snapshot and broadcasts updates to room peers → Member B inspects the thread in Team Workspace → Member B selectively imports it into their local AI session. Real-time broadcast never unconditionally pushes unverified conversations into any member's private AI session.

- **Peer-to-Peer Two-Way Collaboration**: Every member can both share and import; A and B are equal collaborators rather than fixed senders or receivers, never directly merging local private chat sessions;
- **Strict Privacy Boundary**: Unshared conversations remain strictly local on personal devices and are never synced or leaked just by joining a room;
- **Collaboration Hub**: Centralizes room authentication, member permissions, messages, snapshots, real-time presence, task boards, knowledge base, asset libraries, and calendars;
- **Persistence & Plugin Entry**: The Hub persists messages, snapshots, and uploaded files on its host machine; the optional Codex plugin (Skills / Hook) can query Hub summaries and inject them into active tasks;
- **Local Companion Mounting**: The companion app mounts the Team workspace via CDP; CDP operates solely on localhost, while cross-machine communication is handled seamlessly via HTTP API + SSE.

[Editable vector diagram](docs/assets/architecture_en.svg) · [Deployment guide](docs/HUB_DEPLOYMENT.md)

To regenerate both languages as SVG and 3200 × 2240 PNG, run `python3 scripts/generate_architecture_members.py` (or `python3 scripts/generate_architecture_diagram.py`) with Chrome / Chromium installed. Set `CHROME_BIN` to override the browser path.

---

### Live Demo: Cross-Platform Real-Time Sync & Full-Feature Overview (Mac & Windows)

The screencast below demonstrates full-featured real-time collaboration between a **macOS host** and a **Windows 11 peer** (80-second comprehensive demonstration covering task boards, asset management, role-based access, and sub-second context relay with synchronized bilingual commentary; see [docs/assets/teamcodex_demo.mp4](docs/assets/teamcodex_demo.mp4) for the high-definition video):

<p align="center">
  <img src="docs/assets/teamcodex_demo.gif" alt="TeamCodex Live Cross-Platform Demo: Task Board, Asset Distribution, and Instant Context Relay" width="100%" />
</p>

- 📋 **1. Task Board & Workflow Transitions**: Drag-and-drop workflow status (To-Do, In Progress, Done) with instant permission checks and millisecond-level status synchronization;
- 📁 **2. Asset Library & Multi-Format Ingestion**: Instant drag-and-drop ingestion for code files, documentation, images, and folders, creating a unified asset pool;
- 🚀 **3. One-Click Sanitized Share (macOS)**: Click "Share Conversation" in the Codex sidebar, select any active troubleshooting session, and broadcast a privacy-scrubbed snapshot;
- ⚡ **4. Sub-Second Presence & Context Relay (Windows)**: The peer client automatically renders incoming thread cards with zero latency; engineers click "Import Selected Dialogues" to inject verified historical reasoning directly into new prompts, eradicating second-hand communication distortion.

---

### 2. Client Downloads & Tray Companion

Grab pre-built installers directly from **[GitHub Releases](https://github.com/we1jia/TeamCodex/releases)**:

| Platform | Installer | Setup & Experience |
|---|---|---|
| **macOS** | [`TeamCodex-macOS.dmg`](https://github.com/we1jia/TeamCodex/releases/latest) | Drag `TeamCodex.app` into `/Applications`. Status bar upgraded to **Pure White Geometric Vector Cloud Template Icon** with negative space relief and `>_` terminal glyph, adapting automatically to Dark/Light modes; click to open frosted Mini Dashboard |
| **Windows** | [`TeamCodex-Setup.exe`](https://github.com/we1jia/TeamCodex/releases/latest) | Runs setup wizard for ARM64/AMD64. **Left-click opens native dark floating dashboard** (auto-dismiss on blur/Esc); **Right-click opens pristine context menu with instant clean exit**; guarded by global single-instance Mutex |
| **Portable Archives** | `TeamCodex-macOS.zip` / `TeamCodex-Windows-arm64-amd64.zip` | Standalone portable green packages; includes emergency cleanup tool `退出TeamCodex.cmd` |
| **Codex Plugin** | [`TeamCodex-Codex-Plugin.zip`](https://github.com/we1jia/TeamCodex/releases/latest) | Official standard Codex plugin archive; empowers AI with spatial read/write tools, automated `UserPromptSubmit` hook, and preset prompts |

> **Note**: TeamCodex runs as a lightweight tray companion. Click the menu bar or tray icon to open the **Mini Dashboard**:
> - **Live Diagnostics**: Instantly inspect Codex attachment status (🟢 Injected / 🟡 Waiting / 🔴 Disconnected), active Hub, and room occupancy;
> - **One-Click Actions**: Launch & attach Codex, copy Smart Token, switch Hub URL, and restart injection;
> - **In-Place Hot Sync & Updates**: Automatically pulls fresh injection logic; notifies when a new native binary release is available.

---

### 3. Deployment Topology Models

The Hub service supports three standard operational models:

| Model | Host Location | Client Connection | Target Scenario |
|---|---|---|---|
| **Single-Host (Default)** | macOS background auto-spawn | Windows VM auto-detects host bridge IP | Solo developers with Mac + VM setups (Zero config) |
| **Private LAN** | Always-on PC / Mac / NAS in LAN | Enter host LAN IP or paste Smart Token | 5 ~ 30 developer teams on shared office Wi-Fi |
| **Cloud VPS** | Linux Cloud Server | Domain name via Nginx HTTPS proxy | Globally distributed remote teams |

---

### 4. Hub Deployment & Automation (LAN / Cloud)

#### Option A: One-Line Automation Script
```bash
curl -fsSL https://raw.githubusercontent.com/we1jia/TeamCodex/main/scripts/deploy-hub.sh | bash
```
Detects environment automatically: prefers Docker Compose; falls back to Node.js with Systemd / PM2 process supervision and automated health verification.

#### Option B: AI Agent System Prompt
Copy and paste this structured prompt directly to terminal AI assistants (Claude Code, Codex, Cursor, OpenClaw):

```text
Deploy TeamCodex Hub on this server following production standards:
1. Verify system dependencies (Docker/Docker Compose or Node.js >= 18);
2. Clone https://github.com/we1jia/TeamCodex.git to /opt/TeamCodex (or git pull latest main);
3. Prefer docker compose up -d; if Docker is absent, configure systemd service with auto-start;
4. Open port 18765 listening on 0.0.0.0;
5. Validate via: curl http://127.0.0.1:18765/api/health;
6. If Nginx is detected, configure reverse proxy with proxy_buffering off explicitly set for SSE streaming;
7. Output endpoint URL and a ready-to-use Smart Token.
```

Full documentation and Nginx TLS templates available at: **[Hub Deployment & Networking Guide (docs/HUB_DEPLOYMENT.md)](docs/HUB_DEPLOYMENT.md)**.

---

### 5. Core Capabilities

- **Full-Featured Team Workspace (Kanban / Knowledge / Assets / Calendar)**: Natively integrates agile task tracking, review approval flows, full-text searchable docs, SHA-256 deduplicated asset libraries, and work calendars, closing the loop between AI reasoning and engineering lifecycle.
- **Native Embedding & Tray Companion**: Injects via CDP into Codex sidebars paired with a native macOS menubar / Windows tray Mini Dashboard that never intrudes on your main workspace.
- **In-Place Hot Updates**: Automatically synchronizes and caches updated sidebar injection scripts from centralized Hubs without forcing users to re-download binaries.
- **State Machine Mutual Exclusion**: Enforces single-selection highlighting during active collaboration, restoring native thread selections upon exit.
- **Cross-Platform Presence**: Cleanly isolates `Mac` vs `Win` node identities with deduplicated active presence counters and heartbeat tracking.
- **Sanitized Snapshot Relay**: Serializes conversation threads into privacy-safe snapshots, enabling peers to import context with a single click.
- **Smart Token Protocol**: Resolves connection strings formatted as `Hub: <URL> | Room: <Name> | Key: <Password>` instantly with quick clipboard actions.

---

### 6. Official Codex Plugin Integration & AI Capabilities (Plugin / Skills / Hooks)

In addition to the visual sidebar tab and tray companion designed for human engineers, TeamCodex seamlessly integrates with the **official Codex Plugin Architecture** (comprising `.codex-plugin/plugin.json`, semantic `skills/`, and lifecycle `hooks/`).

<p align="center">
  <img src="docs/assets/codex_plugin_detail.png" alt="Official Team Codex Plugin Details and Natural Language Capabilities" width="95%" />
</p>

#### Dual-Core Collaborative Division of Labor
- **Sidebar `Team` Tab (Human Dashboard)**: Designed for **engineers**. Provides immersive fullscreen room chat, real-time presence avatars, multi-room switching, snapshot timeline, and one-click thread imports;
- **`Team Codex` Plugin (AI Hands & Ears)**: Designed for **the active AI Assistant inside your session**. Equips Codex with tool permissions to read/write the team hub, extract discussion summaries, and relay context autonomously via natural language.

#### 1) Three Preset Natural Language Prompts
Execute directly or click prompt pills in the Codex composer:
- **`打开 Team Codex 团队协作空间。 (Open Team Codex Workspace)`**  
  👉 Wakes local daemon and guides user to focus the fullscreen team sidebar;
- **`读取当前团队空间的讨论摘要。 (Fetch Team Discussion Summary)`**  
  👉 Queries the active room compact summary and injects peer consensus and architecture decisions into the current task;
- **`把当前 Codex 对话分享到团队空间。 (Share Conversation to Team Room)`**  
  👉 Packages the current multi-turn reasoning chain, scrubs private local paths, and broadcasts a sanitized snapshot.

#### 2) `UserPromptSubmit` Automated Context Hook
- **Pre-flight Silent Probe**: Before every prompt is dispatched to Codex, the hook issues a lightweight 1200ms request to `http://127.0.0.1:18765/api/compact.txt`;
- **Sub-Second Context Injection**: Dynamically appends the team latest decisions as `additionalContext`, ensuring the AI solutions are grounded in single-source team truth;
- **Zero-Blocking Resilience**: If the Hub is offline or timed out, the hook exits cleanly in 0ms without delaying standard chat.

#### 3) Plugin Installation
- **Source CLI Installation**:
  ```bash
  codex plugin add /path/to/TeamCodex
  ```
- **Offline Import**: Download `TeamCodex-Codex-Plugin.zip` from [GitHub Releases](https://github.com/we1jia/TeamCodex/releases/latest) and import via the Codex Plugins page.

---

### 7. Full-Featured Team Workspace: Kanban, Knowledge Base, Asset Library & Work Calendar (Workspace)

Beyond real-time context relay, TeamCodex natively embeds a **lightweight team workspace engineered for AI-native software delivery**, closing the loop between exploratory prompts, architecture decisions, and task delivery.

<p align="center">
  <img src="docs/assets/team-workspace-board-dark.png" alt="TeamCodex Kanban Board (Dark Mode)" width="49%" />
  <img src="docs/assets/team-workspace-calendar-light.png" alt="TeamCodex Work Calendar (Light Mode)" width="49%" />
</p>
<p align="center">
  <img src="docs/assets/team-workspace-native-light.png" alt="TeamCodex Native Client Integration (Windows Light)" width="80%" />
</p>

#### 1) Agile Kanban Board & Closed-Loop Review Flow
- **Four-Stage Workflow**: Structured progression across 【Backlog (待开始)】, 【In Progress (进行中)】, 【Pending Review (等待审核)】, and 【Completed (已完成)】;
- **Comprehensive Task Metadata**: Assign primary owners, multi-client collaborators (e.g., simultaneously `weijia(Mac)` and `weijia(Win)`), and dedicated reviewers. Track start/due/review dates, priorities, blockers, acceptance criteria, and delivery notes with complete audit logs;
- **Strict Review & Approval Pipeline**: Tasks submitted for review mandate a reviewer and delivery notes. Only designated reviewers can approve or return tasks with required feedback; task contents are locked during review to prevent tampering.

#### 2) Unified Knowledge Base & Asset Library
- **Versatile Document Management**: Supports Markdown writing, code snippets, and multi-format file uploads (up to 10MB, indexing up to 200,000 characters) with full-text search and category/tag filters;
- **Fine-Grained Privacy & Sharing**: Instant toggle between 【Private (仅我可见)】 and 【Project Shared (当前项目共享)】. Private items are strictly guarded and never broadcasted to peers or shared snapshots;
- **SHA-256 Content Addressing**: Shared storage engine automatically deduplicates identical payloads, offering safe in-place image previews and raw file downloads.

#### 3) Multi-Member Work Calendar
- **Cross-Timezone Scheduling**: Automatically visualizes execution and review schedules tailored to each member's configured timezone, workdays, and unavailable dates;
- **Intelligent Schedule Warnings**: Flags non-working day conflicts, overdue milestones, and unscheduled task backlogs to safeguard delivery timelines.

#### 4) Traceable Context Citations
- **Structured Citations**: Select any task or shared asset to generate formatted context blocks with source IDs, version numbers, and snapshot timestamps;
- **Human-in-the-Loop Safeguard**: Inserts context directly into the composer for review and editing—**never automatically dispatches or executes prompts without explicit user confirmation**.

---

### 8. Repository Layout

```text
TeamCodex/
├── .codex-plugin/              # Official Codex plugin manifest (plugin.json)
├── hooks/                      # Lifecycle hook for prompt-time context injection (UserPromptSubmit)
├── skills/                     # Semantic skill instructions (skills/team-codex/SKILL.md)
├── assets/                     # Plugin and application icons, logos & illustrations
├── inject/                     # Client CDP injection, Web Components & UI logic
│   ├── sidebar_fullscreen.js   # Sidebar mount, snapshot scrub, and UI state machine
│   ├── workspace.js            # Workspace components (Kanban/Knowledge/Assets/Calendar) & state
│   ├── workspace.css           # Native-adaptive themes & compact responsive styling
│   └── attach_codex.mjs        # Dynamic script sync, CDP attachment, and heartbeat loop
├── server/                     # Zero-dependency Node.js services
│   ├── dev_host.mjs            # SSE Collab Hub (Port 18765: presence, multi-room, auth)
│   ├── workspace_store.mjs     # Workspace atomic disk write & JSON persistence
│   ├── workspace_routes.mjs    # Workspace RESTful API endpoints & permission guards
│   ├── workspace_validation.mjs # Data validation, length limits & security guards
│   └── launcher_host.mjs       # Local control plane service (Port 18767: status, updates)
├── ui/                         # Frontend UI assets
│   ├── index.html              # Fullscreen standalone collaboration canvas
│   ├── workspace.html          # Workspace standalone entrypoint
│   └── panel.html              # Frosted Mini Dashboard floating card
├── macos/                      # macOS status bar app & packaging
│   ├── TeamCodex.swift         # Native Swift status bar source (Cocoa + WebKit)
│   ├── TeamCodex-Status.png    # Pure white vector cloud template icon (Dark/Light adaptive)
│   ├── launch.sh               # Runtime health supervisor
│   └── build_dmg.py            # Standalone DMG builder with swiftc automation
├── windows/                    # Windows tray suite & NSIS installer
│   ├── tray-teamcodex.ps1      # Native tray companion (Left-click popup + Right-click menu)
│   ├── run-teamcodex.ps1       # Startup supervisor with single-instance mutex
│   ├── 退出TeamCodex.cmd       # [Emergency tool] One-click kill & tray cache cleanup
│   └── installer.nsi           # NSIS setup wizard configuration
├── scripts/                    # Ops & automation deployment scripts (deploy-hub.sh)
├── docs/                       # Architectural manuals & workspace design specs
│   ├── WORKSPACE.md            # Workspace data models, access controls & API guide
│   ├── HUB_DEPLOYMENT.md       # Hub deployment and network topology guide
│   └── assets/                 # Architecture diagrams, screencasts & workspace screenshots
├── tests/                      # Full test suite (workspace, permissions, state machines)
├── version.json                # Client version manifest (v1.2.0)
├── Dockerfile                  # Lightweight Alpine production container definition
├── docker-compose.yml          # Container orchestration configuration
└── README.md
```

---

### 9. Automated Testing

```bash
node --test tests/test_boost_fixes.mjs
node --test tests/test_rooms_and_auth.mjs
node --test tests/test_workspace.mjs tests/test_workspace_bridge.mjs tests/test_workspace_http.mjs
# Verification: Full automated suite passed cleanly (injection, rooms, workspaces & storage)
```

---

### 10. FAQ

- **Q: Do team members need to re-download binaries for regular updates?**  
  **No**. TeamCodex uses dual-track updates: sidebar collaboration scripts update dynamically in-place when connected to a team Hub. Native installers are only required when underlying platform drivers change.
- **Q: Does a solo developer on one machine need to host a cloud server?**  
  **No**. macOS auto-starts the hub in the background, and Windows VM guests auto-detect the bridge IP out of the box.
- **Q: Is conversation data transmitted to external third parties?**  
  **No**. TeamCodex operates purely on self-hosted instances. Data is confined to your own `data/messages.json`.
- **Q: Real-time updates do not reach clients when behind Nginx?**  
  SSE streaming requires unbuffered connections. Ensure **`proxy_buffering off;`** is present in the Nginx `location` block.
