# 团队协作启动器

目标：**双击 App，打开或附着 Codex，并在 Codex 左栏「插件」下面自动出现「团队协作」。** 点击后右侧主区全屏打开协作页。

官方左上角「自定义」列表加不进去。那是 Pull Request / 站点 / 定时任务 / 插件的官方开关。真正入口是左栏多出来的那一行。

## 怎么启动

双击 [团队协作.app](macos/TeamContext.app)，或：

```bash
bash team-context/macos/launch.sh
```

启动器会：

1. 启动本地协作服务 `127.0.0.1:18765`
2. 发现当前 Codex 的调试端口（你这台是 ChatGPT `--remote-debugging-port`）
3. 把「团队协作」注入 Codex 左栏
4. 自己保持运行，页面刷新后会重新加上

不要去「自定义」里找。看左侧「插件」下面。

## 给同事

把 `团队协作.app` 发给同事。他们双击这个 App 来开 Codex，而不是先开官方 ChatGPT 再指望官方菜单里出现一项。

- 若 Codex 已经在跑并且带调试端口：启动器直接附着，不重启。
- 若 Codex 没在跑：启动器会带调试端口拉起官方 ChatGPT.app。
- 若 Codex 在跑但没有调试端口：不会强行杀掉当前窗口。

## 不会碰什么

- 不改 Cockpit Tools、`cockpit-cliproxy`、Sidecar
- 不改 `~/.codex/config.toml`、provider
- 不连 `127.0.0.1:60251` 代理端口

## 分享与空间管理

底部 `Share` 默认读取当前 Codex 本地对话的完整可见线程，并按原生 Share 的快照语义一次发送到当前团队空间。快照会保留用户消息、Codex 可见回复、代码块、链接和捕获报告；内部上下文窗口、隐藏思维链、工具调用与 Shell I/O 会明确标记为未包含。`Import` 才会打开上下文选择卡片，读取团队空间消息，支持鼠标拖选/取消选择、复制 Markdown，再把选中的内容插入当前 Codex 对话。卡片关闭、取消或点击外部输入框，只结束本次导入，不会修改或删除 Codex 本地对话。

当前空间的历史列表中：

- `×` 只移除团队协作插件保存在本机的历史标签和 Room Key，不删除服务端空间，也不删除 Codex 对话。
- `删` 只对当前非 `Media` 空间显示。它需要确认完整空间名和 Room Key，删除的是团队 Hub 的消息、规则、ADR 和共享凭据；系统空间 `Media` 永久受保护。

原生 Codex 的 GPT 分享链接依赖 GPT 站点可访问；团队 Hub 的 `Share Hook` 是本地 Hub 的带 token 链接，适合局域网或 VPN 内协作。两者都不能代替 Git、PR 和测试记录。

## Windows 原生隔离测试

Windows 测试不打开浏览器。双击 [install-test.cmd](windows/install-test.cmd) 安装，再打开桌面的 `TeamContext Windows Test.lnk`。它会启动独立的 Codex/ChatGPT 窗口、独立用户数据目录和独立 CDP 端口，并注入「团队协作」Tab。

启动时会自动放入几条仅用于测试的消息，验证 Share 完整发送、Import 选择导入、鼠标拖选/取消选择和单次发送幂等。详细说明见 [windows/README.md](windows/README.md)。`mock-codex-host.html` 仅保留作静态回归，不是 Windows 默认测试入口。
